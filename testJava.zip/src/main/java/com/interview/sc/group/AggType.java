package com.interview.sc.group;

/**
 * @author yangkuo
 * @date 2025/7/23
 * @description
 */
public enum AggType {
    SUM, AVG, MAX, MIN, COUNT
}

