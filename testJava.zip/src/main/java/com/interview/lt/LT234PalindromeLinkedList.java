package com.interview.lt;

/**
 * LeetCode 234: Palindrome Linked List
 * 题目描述: 判断一个单向链表是否是回文链表。
 * 解法思路: 
 * 1. 使用快慢指针找到链表中点
 * 2. 反转后半部分链表
 * 3. 比较前半部分和后半部分的值
 * 4. 恢复原链表结构（可选）
 */
public class LT234PalindromeLinkedList {
    
    /**
     * 定义ListNode类表示单向链表节点
     */
    public static class ListNode {
        int val;
        ListNode next;
        ListNode(int x) { val = x; }

        public void printList() {
            ListNode current = this;
            while (current != null) {
                System.out.print(current.val + " ");
                current = current.next;
            }
            System.out.println();
        }
    }
    
    /**
     * 判断链表是否为回文
     * @param head 链表头节点
     * @return 是否为回文链表
     */
    public boolean isPalindrome(ListNode head) {
        if (head == null || head.next == null) return true;

        // 1. 快慢指针找中点
        ListNode slow = head, fast = head;
        while (fast != null && fast.next != null) {
            slow = slow.next;
            fast = fast.next.next;
        }

        // 2. 反转后半部分链表
        ListNode reversedHalf = reverseList(slow);
        ListNode p1 = head;
        ListNode p2 = reversedHalf;
        boolean isPalindrome = true;

        // 3. 比较前后两部分
        while (p2 != null) {
            if (p1.val != p2.val) {
                isPalindrome = false;
                break;
            }
            p1 = p1.next;
            p2 = p2.next;
        }

        // 4. 恢复链表（可选）
        reverseList(reversedHalf);
        head.printList();
        return isPalindrome;
    }

    // 反转链表辅助函数
    private ListNode reverseList(ListNode head) {
        ListNode prev = null;
        ListNode curr = head;
        while (curr != null) {
            ListNode nextTemp = curr.next;
            curr.next = prev;
            prev = curr;
            curr = nextTemp;
        }
        return prev;
    }


    public static void main(String[] args) {
        // 测试用例
        LT234PalindromeLinkedList solution = new LT234PalindromeLinkedList();
        
        // 创建测试链表 1->2
        ListNode test1 = new ListNode(1);
        test1.next = new ListNode(2);
        
        // 创建测试链表 1->2->2->1
        ListNode test2 = new ListNode(1);
        test2.next = new ListNode(2);
        test2.next.next = new ListNode(2);
        test2.next.next.next = new ListNode(1);
        
        // 创建测试链表 1->2->3->2->1
        ListNode test3 = new ListNode(1);
        test3.next = new ListNode(2);
        test3.next.next = new ListNode(3);
        test3.next.next.next = new ListNode(2);
        test3.next.next.next.next = new ListNode(1);
        
        // 运行测试用例
        System.out.println("Test case 1 (1->2): ");
        System.out.println(solution.isPalindrome(test1)); // 应该返回false
        
        System.out.println("Test case 2 (1->2->2->1): ");
        System.out.println(solution.isPalindrome(test2)); // 应该返回true
        
        System.out.println("Test case 3 (1->2->3->2->1): ");
        System.out.println(solution.isPalindrome(test3)); // 应该返回true
    }
}